<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

?>
<!DOCTYPE html>
<html>
<body>
<form enctype="multipart/form-data" method="post" role="form" action='#'>
    <div class="form-group">
        <label for="exampleInputFile">File Upload</label>
        <input type="file" name="file" id="file" size="150">
        <p class="help-block">Only Excel/CSV File Import.</p>
    </div>
    <button type="submit" class="btn btn-default" name="submit" value="submit">Upload</button>
</form>
</body>


<?php 



if(isset($_POST["submit"]))
{

    $dbHost     = "localhost";
    $dbUsername = "root";
    $dbPassword = "monkatwork";
    $dbName     = "task1";
    
    // Create database connection
    $db = new mysqli($dbHost, $dbUsername, $dbPassword, $dbName);
    
    // Check connection
    if ($db->connect_error) {
        die("Connection failed: " . $db->connect_error);
    }


          $file = $_FILES['file']['tmp_name'];

         
          $handle = fopen($file, "r");
        
           // Parse data from CSV file line by line
           while(($line = fgetcsv($handle)) !== FALSE){
            // Get row data
            $first_name   = $line[0];
            $last_name    = $line[1];
            $email        = $line[2];
            $phone        = $line[3];
            $city         = $line[4];
            $zipcode      = $line[5];
            $country      = $line[6];
            $status       = $line[7];
            
                // Insert member data in the database
                $db->query("INSERT INTO wp_nab_members (first_name, last_name, email, phone, city, zip, country, status) VALUES ('".$first_name."', 
                '".$last_name."', 
                '".$email."', 
                '".$phone."', 
                '".$city."', 
                '".$zipcode."', 
                '".$country."', 
                '".$status."')");
               
        }
        
        // Close opened CSV file
        fclose($handle);
       

           

}
?>
</html>

