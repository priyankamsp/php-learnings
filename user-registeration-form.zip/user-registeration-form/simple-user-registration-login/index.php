<?php


include("auth.php"); //include auth.php file on all secure pages ?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<link rel="stylesheet" href="style.css" />
<title>Welcome Home</title>

</head>
<body>
<div class="form">
<p>Welcome <?php echo $_SESSION['username']; ?>!</p>

<a href="logout.php">Logout</a>


<br /><br /><br /><br />

</div>
</body>
</html>
